<?php

$PHPBLOCKS_CONFDIR   = dirname(__FILE__);
$PHPBLOCKS_DATADIR   = $PHPBLOCKS_CONFDIR . "/data/";

date_default_timezone_set("Europe/Dublin");
?>
