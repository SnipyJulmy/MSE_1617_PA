
// the document to load.
var jsonDocument = 
    [
      {
          "type": "draw2d.shape.analog.OpAmp",
          "id": "ebfb35bb-5767-8155-c804-14bd48789dc21",
          "x": 72,
          "y": 45,
          "width": 100,
          "height": 100
        }
      ,
      {
          "type": "draw2d.shape.analog.OpAmp",
          "id": "ebfb35bb-5767-8155-c804-14bd48789dc22",
          "x": 72,
          "y": 45
        }
     ];
